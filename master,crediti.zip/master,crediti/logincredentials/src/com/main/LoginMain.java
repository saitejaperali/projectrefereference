package com.main;

import java.util.Date;
import java.util.Scanner;

import com.bo.LoginBo;
import com.bo.LoginBoImp;
import com.exception.BusinessException;
import com.to.User;

public class LoginMain {
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
			System.out.println("welcome to login app v1.0");
			System.out.println("============================");
			
			User user=new User();
			System.out.println("enter username");
			user.setUsername(scanner.next());
			System.out.println("enter password");
			user.setPassword(scanner.next());
			LoginBo bo=new LoginBoImp();
			try {
				if(bo.isValidUser(user))
				{
					System.out.println("welcome" +user.getUsername());
					System.out.println("you have logged in successfully @"+new Date());
				}
			}catch(BusinessException e)
			{
				e.printStackTrace();
			}
	}
}
