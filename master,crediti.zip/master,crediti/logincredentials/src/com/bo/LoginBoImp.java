package com.bo;

import com.dao.LoginDao;
import com.dao.LoginDaoImpl;
import com.exception.BusinessException;
import com.to.User;

public class LoginBoImp implements LoginBo {
	private LoginDao logindao;
	@Override
	public boolean isValidUser(User user) throws BusinessException {
    boolean b=false;
    if(user!=null && user.getUsername()!=null && user.getPassword()!=null) {
    	if(user.getUsername().matches("[a-zA-Z]{4,7}[0-9]{4}") && 
    			user.getPassword().matches("[a-zA-Z]{3,7}@[0-9]{3}")) {
    		//code here for dao
    		logindao=new LoginDaoImpl();
    		b=logindao.isValidUser(user);
    	}
    }
    if(b==false)
    {
    	throw new BusinessException("Invalid logon credentials");
    }
		return b;
	}

}
