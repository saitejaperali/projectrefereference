package com.bo;

import com.dao.LoginDAOImpl;
import com.exception.BusinessException;
import com.to.User;

public class LoginBOImpl implements LoginBO {

	private LoginDAOImpl logindao;

	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		if(user!=null && user.getUsername()!=null && user.getPassword()!=null )
		{
			if(user.getUsername().matches("[a-zA-Z]{2,7}[0-9]{2,5}") &&
					user.getPassword().matches("[a-z]{3,7}@[0-9]{3}"))
			{
				//CODE HERE FOR DAO
				logindao = new LoginDAOImpl();
				b = logindao.isValidUser(user);
			}
		}
		if(b == false)
		{
			throw new BusinessException("Invalid Credentials");
		}
		return b;
	}

}
