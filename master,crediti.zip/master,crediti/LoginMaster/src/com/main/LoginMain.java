package com.main;

import java.util.Scanner;

import com.bo.LoginBO;
import com.bo.LoginBOImpl;
import com.bo.RegisterBOImpl;
import com.exception.BusinessException;
import com.to.User;

public class LoginMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		User user = new User();
		int a ;
		System.out.println("Welcome to Login Api");
		System.out.println("~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("1. Registration");
		System.out.println("2. Login");
		System.out.println("Enter your choice");
		a = sc.nextInt();
		switch(a)
		{
		case 1 :
			System.out.println("Enter Username");
			user.setUsername(sc.next());
			System.out.println("Enter Password");
			user.setPassword(sc.next());
			LoginBO lbo = new RegisterBOImpl();
			try {
				if(lbo.isValidUser(user))
				{
					System.out.println("Welcome " + user.getUsername());
					System.out.println("UserRegistered Successfully");
				}
			} catch (BusinessException e1) {
				System.out.println(e1.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter Username");
			user.setUsername(sc.next());
			System.out.println("Enter Password");
			user.setPassword(sc.next());
		
			LoginBO bo = new LoginBOImpl();
			try
			{
				if(bo.isValidUser(user))
				{
					System.out.println("Welcome " + user.getUsername());
					System.out.println("You have logged in successfully");
				}
			} 
			catch (BusinessException e) 
			{
				System.out.println(e.getMessage());
			}
		}
	}

}
