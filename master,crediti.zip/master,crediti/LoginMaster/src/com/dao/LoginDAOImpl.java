package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbUtil.OracleDBConnection;
import com.exception.BusinessException;
import com.to.User;

public class LoginDAOImpl implements LoginDAO {
	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		Connection con = null;
		try {
			con = OracleDBConnection.getConnection();
			String sql = "select username from LoginMaster where username = ? and password = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				b = true;
			}
			else
			{
				throw new BusinessException("Internal Error Occured...");
			}
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			System.out.println(e);
			throw new BusinessException("Internal Error Occured...");
		}
		finally
		{
			try {
				con.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e);
				throw new BusinessException("Internal Error Occured...");
			}
		}
		return b;
	}
	
}
