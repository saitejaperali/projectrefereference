
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.jar.Attributes.Name;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/second")
public class Second extends GenericServlet 
{
public void init()
{
	System.out.println("init");
}
	@Override
	public void service(ServletRequest req, ServletResponse res)	throws ServletException, IOException 
			{
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String empno=req.getParameter("t1");
		String name=req.getParameter("t2");
		String email=req.getParameter("t3");
		String phoneno=req.getParameter("t4");
		pw.println("The empno is "+empno);
		pw.println("<br>");
		pw.println("The name is "+name);
		pw.println("<br>");
		pw.println("The email is "+email);
		pw.println("<br>");
		pw.println("The phone no is "+phoneno);
		try
		{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		PreparedStatement st=con.prepareStatement("insert into employee values(?,?,?,?)");
	
		st.setString(1,empno);
		st.setString(2,name);
		st.setString(3,email);
		st.setString(4,phoneno);
		st.execute();
		pw.println("row inserted");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}
	public void destroy()
	{
		System.out.println("destroy");
	}
	
	}