$(function(){
$('form[id="form"]').validate({
rules : {
	name : "required",
	Email : "required",
	Mobile_number : "required",
	Username : " required ",
	Address : "required",
	Password : "required",
	answer : "required",

Username : {
required : true,
// minlength:6,
},
Password : {
required : true,
minlength:8,
},
login_password : {
	required:true,
},
name : {
	required : true,
},
from: {
required : true
},
uid : {
required : true
},
book_id : {
	required : true
},
to : {
	required : true
},
author_name : {
required : true
},
book_name : {
	required : true,
},
book_edition : {
	required : true,
},
book_type : {
	required : true,
},

Mobile_number : {
	required : true,
	number: true,
	minlength : 10,
	maxlength : 10
},

Email : {
	required : true,
},

Address : {
	required : true,
	maxlength : 50
},
answer : {
	required : true,
},
New_Password : {
	required : true,
},
Confirm_Password : {
	required : true,
	equalTo : '[name="New_Password"]',
},
reg_type : {
	required : true,
}
},
messages : {
	Username : {
		required : "Username is required",
	},
	Password : {
		required : "Password is required",
	},
				
	book_id : {
		required : "Book ID is required",
	},
	from : {
		required : " date is required",
	},
	to : {
		required : "Return date is required",
	},
	book_name : {
		required : "Book name is required ",
	},
	author_name : {
		required : "Author name is required",
	},
	Address : {
		required : "Address is required",
	},
	name : {
		required : "Name is required",
	},
	Mobile_number : {
		required : "Mobile number is required",
	},
	Email : {
		required : "Email is required",
	},
	answer : {
		required : "Please answer  your security Question",
	},
	New_Password  : {
		required : "Please enter New Password",
	},
	Confirm_Password : {
		required : "Please enter confirm password",
	},
	book_type : {
		required : "Book type is required",
	},
	book_edition : {
		required : "Book Edition is required",
	},
	reg_type : {
		required : "Registration type is required",
	},
	login_password : {
		required : "Password is required",
	}
	
	
},

submitHandler:function(form){
form.submit();
}
});
});
				