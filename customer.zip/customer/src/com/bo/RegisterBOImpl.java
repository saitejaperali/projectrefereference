package com.bo;

import com.dao.LoginDAOImpl;
import com.dao.RegisterDAOImpl;
import com.exception.BusinessException;
import com.to.User;

public class RegisterBOImpl implements LoginBO {

	private RegisterDAOImpl registerdao;

	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		if(user!=null && user.getUsername()!=null && user.getPassword()!=null )
		{
			if(user.getUsername().matches("[a-zA-Z]{2,7}[0-9]{3}") &&
					user.getPassword().matches("[a-z]{3,7}@[0-9]{3}"))
			{
				//CODE HERE FOR DAO
				registerdao = new RegisterDAOImpl();
				b = registerdao.isValidUser(user);
			}
		}
		if(b == false)
		{
			throw new BusinessException("Invalid Credentials");
		}
		return b;

	}

}
