package com.to;

import java.util.Date;

public class Customer {
	
	private String cusid;
	private String name;
	private Date dob;
	private long contact;
	private String city;
	
	
	
	public Customer()
	{
		
	}
	
	
	public Customer(String name, Date dob, long contact, String city) {
		super();
		this.name = name;
		this.dob = dob;
		this.contact = contact;
		this.city = city;
	}


	public Customer(String cusid, String name, Date dob, long contact, String city) 
	{
		super();
		this.cusid = cusid;
		this.name = name;
		this.dob = dob;
		this.contact = contact;
		this.city = city;
	}
	
	public String getCusid() {
		return cusid;
	}
	public void setCusid(String cusid) {
		this.cusid = cusid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
