package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dbUtil.OracleDBConnection;
import com.exception.BusinessException;
import com.to.User;

public class RegisterDAOImpl implements LoginDAO {

	@Override
	public boolean isValidUser(User user) throws BusinessException {
		boolean b = false;
		Connection con = null;
		User usr = new User(user.getUsername(), user.getPassword());
		try {
			con = OracleDBConnection.getConnection();
			String sql = "insert into LoginMaster(username, password)"
					+ "values(?,?) ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, usr.getUsername());
			ps.setString(2, usr.getPassword());
			
			int rs = ps.executeUpdate();
			b = true;
			
		} 
		catch (ClassNotFoundException | SQLException e) 
		{
			throw new BusinessException("user already present");
		}
		return b;
	}

}
