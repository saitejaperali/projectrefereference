package com.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;


import com.DButil.OracleDBConnection;
import com.to.Customer;

public class CustomerDAO
{
	public Customer registerCustomer(Customer customer)
	{
		
		Connection connection=null;
		
		try 
		{
			connection=OracleDBConnection.getConnection();
//			String sql="{call registerCustomer(?,?,?,?,?)}";//by using procedure
			String sql1="{?=call registerCustomer1(?,?,?,?)}";//by using function
			CallableStatement callableStatement=connection.prepareCall(sql1);
			callableStatement.setString(2, customer.getName());
			callableStatement.setDate(3, new java.sql.Date(customer.getDob().getTime()));
			callableStatement.setLong(4, customer.getContact());
			callableStatement.setString(5, customer.getCity());
			
			callableStatement.registerOutParameter(1, java.sql.Types.VARCHAR);
			
			callableStatement.execute();
			
			customer.setCusid(callableStatement.getString(1));
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		} 
		finally
		{
			try 
			{
				connection.close();
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return customer;
	}
	
}
