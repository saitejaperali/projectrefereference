package com.main;

import java.util.Date;

import com.dao.CustomerDAO;
import com.to.Customer;

public class Main
{

	public static void main(String[] args)
	{
		Customer customer=new Customer("gayathri",new Date(),122345678,"banglore");
		CustomerDAO dao=new CustomerDAO();
		customer=dao.registerCustomer(customer);
		if(customer.getCusid()!=null)
		{
			System.out.println("customer registered successfully");
			System.out.println("please make note of your customer id");
			System.out.println(customer.getCusid());
		}
			else
			{
				System.out.println("register failure");
			}
		}
	}


