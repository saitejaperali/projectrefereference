package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RemoveBookDAO {

	@Autowired
	private SessionFactory factory;

	public Integer removeBook(Integer bookId) {
		Transaction transaction = null;
		Integer NoOfBookRemove = null;
		String hql = "delete from AddBookDTO remove where remove.bookid=:name";

		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("name", bookId);
			NoOfBookRemove = query.executeUpdate();
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		}
		return NoOfBookRemove;
	}

}
