package com.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TBL_RESERVED_BOOK_DETAILS")
public class CustomerOrderDTO implements Serializable {
	
	@Id
	@Column(name="BOOK_ID")
	private Integer bookid;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Issue_Date")
	private String issueDate;
	
	@Column(name="Return_Date")
	private String returnDate;
	
	public CustomerOrderDTO(){
		System.out.println(this.getClass().getSimpleName()+" Object created");
	}

	public Integer getBookid() {
		return bookid;
	}

	public void setBookid(Integer bookid) {
		this.bookid = bookid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	
	

}
