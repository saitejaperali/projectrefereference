package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.DonorOrderDTO;

import com.service.RegistrationService;

@Controller
public class DonorOrderController {
	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/donororder.do")
	public ModelAndView register(@RequestParam String book_name, @RequestParam String author_name, 
			@RequestParam String book_type, @RequestParam String from, @RequestParam String Email,
			@RequestParam String Address) {

		DonorOrderDTO donororderDTO = new DonorOrderDTO();
		donororderDTO.setEmail(Email);
		donororderDTO.setBookname(book_name);
		donororderDTO.setAuthorname(author_name);
		donororderDTO.setBooktype(book_type);
		donororderDTO.setPickupdate(from);
		donororderDTO.setPickupaddress(Address);
		
		
		
		boolean register = registrationService.donorOrder(donororderDTO);

		if (register) {
			return new ModelAndView("donor_order_thankyou.html");
		} else {
			return new ModelAndView("Fail.html");
		}
	}

}
