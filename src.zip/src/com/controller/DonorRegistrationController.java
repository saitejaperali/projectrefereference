package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.dto.DonorRegistrationDTO;
import com.service.RegistrationService;

@Controller
public class DonorRegistrationController {
	
	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/reg1.do")
	public ModelAndView register(@RequestParam String name, @RequestParam String Email, @RequestParam Long Mobile_number,
			@RequestParam String Password, @RequestParam String Address, 
			@RequestParam String securityquestions, @RequestParam String answer) {

		DonorRegistrationDTO donorregistrationDTO = new DonorRegistrationDTO();
		donorregistrationDTO.setName(name);
		donorregistrationDTO.setEmail(Email);
		donorregistrationDTO.setAddress(Address);
		donorregistrationDTO.setPassword(Password);
		donorregistrationDTO.setMobile_number(Mobile_number);
		donorregistrationDTO.setSecurityquestions(securityquestions);
		donorregistrationDTO.setAnswer(answer);
		
		boolean register = registrationService.donorRegister(donorregistrationDTO);

		if (register) {
			return new ModelAndView("rsuccess.html");
		} else {
			return new ModelAndView("failRegister.html");
		}
	}

}
