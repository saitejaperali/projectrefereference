package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.CustomerRegistrationDTO;

import com.service.RegistrationService;

@Controller
public class CustomerRegistrationController {
	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/reg.do")
	public ModelAndView register(@RequestParam String name, @RequestParam String Email, @RequestParam Long Mobile_number,
			@RequestParam String Password, @RequestParam String Address, 
			@RequestParam String securityquestions, @RequestParam String answer) {

		CustomerRegistrationDTO customerregistrationDTO = new CustomerRegistrationDTO();
		customerregistrationDTO.setName(name);
		customerregistrationDTO.setEmail(Email);
		customerregistrationDTO.setAddress(Address);
		customerregistrationDTO.setPassword(Password);
		customerregistrationDTO.setMobile_number(Mobile_number);
		
		customerregistrationDTO.setSecurityquestions(securityquestions);
		customerregistrationDTO.setAnswer(answer);
		

		
		boolean register = registrationService.register(customerregistrationDTO);

		if (register) {
			return new ModelAndView("rsuccess.html");
		} else {
			return new ModelAndView("Fail.html");
		}
	}

}
