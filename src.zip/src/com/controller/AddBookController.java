package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.AddBookDTO;
import com.service.RegistrationService;

@Controller
public class AddBookController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/addbook.do")
	public ModelAndView AddBookSave( @RequestParam String book_name,
			@RequestParam String author_name, @RequestParam String book_type, @RequestParam String book_edition ) {
		
		AddBookDTO addBookDTO = new AddBookDTO();
		addBookDTO.setBookname(book_name);
		addBookDTO.setAuthorname(author_name);
		addBookDTO.setBooktype(book_type);
		addBookDTO.setBookedition(book_edition);
		
		boolean booksave = registrationService.booksave(addBookDTO);
		if(booksave) {
			return new ModelAndView("admin_addbook.html");
		}else {
			return new ModelAndView("addbookk.html");
		}
	}

}
